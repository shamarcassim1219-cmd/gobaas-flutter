# MYBAAS API Reference — for Flutter

Base URL: `https://api.findbass.store`

All authenticated endpoints expect:
```
Authorization: Bearer <token>
Content-Type: application/json
```

Every response follows `{ success: true/false, message?, ...data }`.
On error, HTTP status is non-2xx and `success: false` with a human-readable `message`.
Some errors also include a `code` field for programmatic handling (see MOBILE_REQUIRED,
PLATFORM_FEE_DUE below) — always check `code` before falling back to showing `message`.

⚠️ **DEPRECATED — do not use in the Flutter app:**
- `POST /api/auth/register` — creates an account with NO OTP verification (mobile
  ownership never proven). Legacy, insecure. Use the OTP flow below instead.
- `POST /api/payments/payhere/create` + `POST /api/payments/payhere/notify` — an old,
  inconsistent wallet-crediting path that writes to a field (`user.walletBalance`)
  nothing else reads. Use `/api/wallet/payhere/create` instead (documented below).

---

## 1. Auth

### Register (new number) — 2-step OTP
```
POST /api/auth/register/request-otp
Body: { mobile: "07XXXXXXXX" }
→ { success, message }
```
```
POST /api/auth/register/verify-otp
Body: { mobile, otp: "123456", role?: "baas" }   // omit role, or "customer", for the customer app
→ { success, token, user: {...} }
```
`token` here is short-lived (30 min) — call `PUT /api/users/profile` with
`firstName`/`lastName` right after to finish setup and get a full session.
The Baas app must send `role: "baas"` here — this is what flags the account
correctly for every baas-only endpoint below.

### Login (existing number)
```
POST /api/auth/login
Body: { mobile }
→ { success, message }   // 404 if no account exists with this mobile
```
```
POST /api/auth/verify-otp
Body: { mobile, otp }
→ { success, token, user: {...} }   // 7-day token
```

### Guest account (customer app only — browse without a phone number)
```
POST /api/auth/guest-register
Body: {}   // name is optional
→ { success, token, user: {...} }
```
A guest can browse and search freely. The backend blocks `POST /api/orders`
with `428 MOBILE_REQUIRED` until they verify a real mobile number — the app
should catch that code and drop into the OTP flow above, then retry the order.

### Current user
```
GET /api/users/me
→ { success, user: { id, mobile, email, firstName, middleName, lastName,
      profilePhoto, verification, role, baasProfile } }
```

### Update profile
```
PUT /api/users/profile
Body: { firstName?, middleName?, lastName?, email?, profilePhoto? }
→ { success, user: {...} }
```
Only send the fields being changed — omitted fields are left alone.

---

## 2. Security (email / mobile change — both apps)

```
POST /api/security/email/request-otp    Body: { email }
POST /api/security/email/verify-otp     Body: { email, otp }  → { user }
POST /api/security/mobile/request-otp   Body: { mobile }
POST /api/security/mobile/verify-otp    Body: { mobile, otp } → { user }
```

---

## 3. Verification (identity — both apps)

```
POST /api/users/verification
Body: { fullName, nic, phone, address, province, district, nicPhoto: "data:image/..." }
→ { success, verification: { status: "Pending", ... } }
```
`nicPhoto` is a base64 data URL (same pattern as `profilePhoto`).
Status becomes `"Approved"` / `"Rejected"` once admin decides (see §8).

---

## 4. Baas Search (customer app)

```
GET /api/professionals?lat=&lng=&radius=30&service=
→ { success, professionals: [{
      id, name, initials, service, services[], location, distanceKm,
      rating, reviews, price, verified, about, profilePhoto,
      completedOrders, reviewList: [{ name, rating, comment, createdAt }]
    }], searchedWithRealLocation }
```
`lat`/`lng` optional — omit for a text-only fallback match. `service` optional —
omit to get every nearby Baas regardless of category.

---

## 5. Orders (customer app)

```
POST /api/orders
Body: { service, professionalId?, professionalName?, location, days, dailyRate,
        preferredDate, paymentMethod: "pay_now"|"pay_direct", latitude?, longitude?, photos?: [] }
→ 428 { code: "MOBILE_REQUIRED" }  — if mobile not yet verified (see §1)
→ 201 { success, order: {...} }
```

```
GET /api/orders                    → { success, orders: [...] }   // this user's own orders
GET /api/orders/:id                → { success, order: {...} }
```

### Pay Now (card via PayHere)
```
POST /api/orders/:id/payment/payhere
→ { success, merchantId, orderId, amount, currency, hash, sandbox,
    firstName, lastName, email, phone, address, city, country }
```
Feed this straight into the PayHere mobile SDK's payment object.
On dismiss/error client-side, call:
```
POST /api/orders/:id/payment-failed
→ { success }   // creates a "tap to retry" notification for this order
```

### If payment or order placement fails
Order stays `Pending`/unpaid — nothing else to do beyond the call above;
the customer can resume from the notification later, re-driving the same
`/payment/payhere` call for that `orderId`.

---

## 6. Order Lifecycle (baas app)

```
GET /api/baas/orders?type=incoming        → nearby Pending/Awaiting-Baas orders
GET /api/baas/orders?type=active          → orders this Baas accepted, not yet complete
GET /api/baas/orders?type=completed       → this Baas's finished jobs
```
`incoming` items: `{ id, orderId, service, location, distanceKm, days, dailyRate,
total, preferredDate, status, directRequest, createdAt }`.
`active`/`completed` items additionally include `customerName`, `customerMobile`
(only ever revealed once accepted).

```
POST /api/orders/:id/accept     → releases escrow to the Baas wallet immediately
POST /api/orders/:id/reject     → refunds the customer if already paid
PUT  /api/orders/:id/complete   → only the Baas who accepted it may call this
```

---

## 7. Baas Profile & Availability (baas app)

```
PUT /api/baas/profile
Body: { services: ["Painting", ...], dailyRate, about?, displayName?, location?, profilePhoto? }
→ { success, baasProfile: {...} }
```
```
PUT /api/baas/location     Body: { latitude, longitude }
```
```
PUT /api/baas/availability   Body: { active: true|false }
→ 402 { code: "PLATFORM_FEE_DUE", feeOwed }   — if fee owed > Rs. 50 and active:true
```
On `PLATFORM_FEE_DUE`, route the app to the platform-fee screen (§10) instead
of showing a generic error.

---

## 8. Reviews

```
POST /api/reviews    Body: { orderId, rating: 1-5, comment }   // customer, order must be Completed
GET  /api/reviews/:baasId   → { success, reviews: [...] }      // public
```

---

## 9. Wallet (both apps — customers use top-up, Baas use earnings/withdraw)

```
GET /api/wallet
→ { success, wallet: { available, pending, ... }, ledger: [{ type, amount, note, createdAt, state }] }
```
`amount` is signed (positive = credit, negative = debit) — use the sign for
color/±, don't infer it from `type`.

```
POST /api/wallet/payhere/create
Body: { amount, purpose?: "topup" | "platform_fee" }   // default "topup", min Rs.100 for topup only
→ { orderId, merchantId, amount, currency, hash, sandbox, firstName, ... }
```
Same PayHere payment-object shape as §5 — feed to the SDK the same way.

```
POST /api/wallet/withdrawals
Body: { amount (min 1000), bankName, accountName, accountNumber, branch? }
→ { success, request: {...} }   // status starts "Requested"
```
```
GET /api/wallet/withdrawals          → own requests
GET /api/wallet/withdrawals?all=true → ALL requests (admin only)
```

---

## 10. Platform Fee (baas app only)

```
GET /api/baas/platform-fee
→ { success, feeOwed, feePercent: 2.5, blockThreshold: 50, blocksGoingOnline }
```
```
POST /api/baas/platform-fee/pay-wallet
→ { success }   // deducts feeOwed from wallet balance, zeroes it out
```
To pay by card instead, call `POST /api/wallet/payhere/create` with
`purpose: "platform_fee"` and `amount: feeOwed`, then run the same PayHere flow.

---

## 11. Notifications (both apps)

```
GET /api/notifications                    → { success, notifications: [{ id, title, message, type, data, read, createdAt }] }
GET /api/notifications/stream?token=...   → Server-Sent Events, real-time push
PUT /api/notifications/:id/read
PUT /api/notifications/read-all
DELETE /api/notifications/:id
```
`type` values in use: `order`, `payment`, `payment_failed`, `security`,
`account`, `review`, `support`. Use `type` to pick an icon; `data.orderId`
(when present) tells you what tapping the notification should open.

For Flutter, SSE (`EventSource`-equivalent) needs a package like
`flutter_client_sse` — or simplest to start: poll `GET /api/notifications`
every 30-60s, matching how the web apps already fall back when SSE drops.

---

## 12. Support & Complaints (both apps)

```
POST /api/support/requests   Body: { subject, message }
GET  /api/support/requests   → own requests

POST /api/support/chats                         → opens a live chat thread
GET  /api/support/chats                          → own chat list
GET  /api/support/chats/:id                       → messages in one chat
POST /api/support/chats/:id/messages   Body: { message }
PUT  /api/support/chats/:id/close
DELETE /api/support/chats/:id

POST /api/complaints
Body: { orderId, reason, details, photos?: ["data:image/...", ...] }
GET  /api/complaints          → own complaints
GET  /api/complaints/:id
```

---

## 13. Admin (kept on the web admin panel — not part of the Flutter apps)

Listed for completeness only:
```
GET  /api/admin/dashboard-stats
GET  /api/admin/users?q=&role=
GET  /api/admin/orders?q=&status=
GET  /api/admin/complaints?status=
GET  /api/admin/support-requests?status=
GET  /api/admin/verifications?status=
PUT  /api/admin/verification/:userId    Body: { status: "Approved"|"Rejected", note? }
PUT  /api/complaints/:id/decision       Body: { decision: "Approved"|"Rejected", adminNote? }
PUT  /api/support/requests/:id/status   Body: { status }
PUT  /api/wallet/withdrawals/:id        Body: { status: "Approved"|"Paid"|"Rejected", reference? }
POST /api/admin/notifications           Body: { title, message, toAll? | role? | userId? }
PUT  /api/orders/:id/status             Body: { status }   // admin override
```

---

## Common error codes to branch on

| `code` | Where | Meaning |
|---|---|---|
| `MOBILE_REQUIRED` | `POST /api/orders` | Verify mobile inline, then retry the same call |
| `PLATFORM_FEE_DUE` | `PUT /api/baas/availability` | Route to platform-fee screen, show `feeOwed` |

Everything else: show `message` as-is, it's already written for end users.

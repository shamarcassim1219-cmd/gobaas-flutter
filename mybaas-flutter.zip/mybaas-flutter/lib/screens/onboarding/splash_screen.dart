import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../services/auth_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/brand_logo.dart';
import 'language_screen.dart';
import '../home/home_shell.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _decideNextScreen();
  }

  Future<void> _decideNextScreen() async {
    // A brief, deliberate pause - long enough for the logo animation
    // to actually be seen, short enough that it never feels like a
    // stall. Real auth-check work happens in parallel underneath.
    final loggedInFuture = AuthService.instance.isLoggedIn();
    final results = await Future.wait([
      loggedInFuture,
      Future.delayed(const Duration(milliseconds: 1100)),
    ]);

    if (!mounted) return;

    final loggedIn = results[0] as bool;

    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: AppMotion.medium,
        pageBuilder: (_, animation, __) => FadeTransition(
          opacity: animation,
          child: loggedIn ? const HomeShell() : const LanguageScreen(),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const BrandLogo(fontSize: 36),
            const SizedBox(height: 14),
            Text(
              'Hire trusted professionals',
              style: Theme.of(context).textTheme.bodyMedium,
            ).animate().fadeIn(delay: 300.ms, duration: AppMotion.medium),
          ],
        ),
      ),
    );
  }
}
